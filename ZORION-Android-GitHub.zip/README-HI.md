# ZORION AI — GitHub se APK banayein

Is project mein aapki `ZORION-v3-enhanced.html` file ko Android app ke andar chalane ke liye Capacitor wrapper aur GitHub Actions workflow diya gaya hai.

## APK banane ka sabse aasan tareeqa

1. ZIP extract karein.
2. GitHub par naya repository banayein, jaise `zorion-ai-android`.
3. Is folder ke **saare files/folders** repository mein upload karein. `www/index.html` zaroor upload ho.
4. Repository mein **Actions** tab kholein.
5. `Build ZORION AI APK` workflow select karein.
6. **Run workflow** dabayein. Pehli baar workflow ko dikhne mein kuch minute lag sakte hain.
7. Build successful hone par usi workflow run ke neeche **Artifacts** mein `ZORION-AI-debug-APK` download karein.
8. ZIP artifact extract karein. Uske andar `app-debug.apk` hoga. APK ko apne Android phone par bhejkar install karein. Android agar pooche to browser/file manager ke liye “Install unknown apps” allow karna padega.

`main` branch par push karne se bhi workflow automatic chalega.

## Zaroori baatein

- Yeh **debug APK** banata hai, Play Store ke liye signed release APK/AAB nahi.
- ZORION ke AI replies ke liye app ke Settings mein apni supported provider API key set karni hogi. API key ko GitHub repository ya HTML source code mein mat daalein.
- Aapki HTML app ki kuch browser features Android WebView mein alag behave kar sakti hain. Voice recognition, microphone permission aur provider API/CORS behavior ko phone par test karein.
- Is HTML app se akela native desktop control, background service ya Windows-only functions nahi milte.
- GitHub Actions fail ho to workflow ke log mein pehla red/error step kholein; error text share karenge to troubleshoot kiya ja sakta hai.

## Project files

- `www/index.html` — aapki ZORION HTML app
- `capacitor.config.json` — Android app ka naam aur package ID
- `package.json` — Capacitor dependencies
- `.github/workflows/build-apk.yml` — cloud par APK build karne ka workflow

App package ID: `com.zorion.ai`
